export interface AldItem {
  code: string;
  name: string;
  children?: AldItem[];
}

// Source: Nouvelle nomenclature codifiée des ALD
export const aldData: AldItem[] = [
  {
    code: "C01",
    name: "Tuberculoses sous toutes ses formes",
    children: [
      {
        code: "C01A",
        name: "Tuberculose pleuro-pulmonaire",
        children: [
          { code: "C01A01", name: "Tuberculose pulmonaire" },
          { code: "C01A02", name: "Tuberculose pleurale" },
        ],
      },
      {
        code: "C01B",
        name: "Tuberculose extrapulmonaire",
        children: [
          { code: "C01B01", name: "Tuberculose du système nerveux" },
          { code: "C01B02", name: "Tuberculose digestive" },
          { code: "C01B03", name: "Tuberculose de l'appareil génito-urinaire" },
          { code: "C01B04", name: "Tuberculose ganglionnaire" },
          { code: "C01B05", name: "Tuberculose des os et des articulations" },
          { code: "C01B06", name: "Autres Tuberculoses" },
        ],
      },
    ],
  },
  {
    code: "C02",
    name: "Les psycho-névroses graves",
    children: [
      {
        code: "C02A",
        name: "Psychoses graves",
        children: [
          { code: "C02A01", name: "Schizophrénie paranoïde" },
          { code: "C02A02", name: "Schizophrénie hébéphrénique" },
          { code: "C02A03", name: "Schizophrénie catatonique" },
          { code: "C02A04", name: "Schizophrénie simple" },
          { code: "C02A05", name: "Troubles délirants persistants" },
          { code: "C02A06", name: "Psychose hallucinatoire chronique" },
        ],
      },
      {
        code: "C02B",
        name: "Troubles de l'humeur persistants",
        children: [{ code: "C02B01", name: "Trouble affectif bipolaire" }],
      },
      {
        code: "C02C",
        name: "Névroses graves",
        children: [
          { code: "C02C01", name: "Névrose phobique grave" },
          { code: "C02C02", name: "Névrose hystérique grave" },
          { code: "C02C03", name: "Névrose obsessionnelle grave" },
        ],
      },
    ],
  },
  {
    code: "C03",
    name: "Les maladies cancéreuses",
    children: [
        { code: "C03A", name: "Cancer du système nerveux", children: [{ code: "C03A01", name: "Cancer des méninges" }, { code: "C03A02", name: "Cancer de l'encéphale" }, { code: "C03A03", name: "Cancer de la moelle épinière, des nerfs crâniens et d" }] },
        { code: "C03B", name: "Cancer de la sphère ORL", children: [{ code: "C03B01", name: "Cancer de l'oreille" }, { code: "C03B02", name: "Cancer du nez" }, { code: "C03B03", name: "Cancer du larynx" }, { code: "C03B04", name: "Cancer du cavum" }, { code: "C03B05", name: "Cancer de la glande parotide" }, { code: "C03B06", name: "Cancer des glandes salivaires" }, { code: "C03B07", name: "Cancer de l'oropharynx" }, { code: "C03B08", name: "Cancer du sinus" }, { code: "C03B09", name: "Cancer de l'hypopharynx" }] },
        { code: "C03C", name: "Cancer de l'œil", children: [{ code: "C03C01", name: "Rétinoblastome" }, { code: "C03C02", name: "Mélanome" }, { code: "C03C03", name: "Autres cancers de l'œil" }] },
        { code: "C03D", name: "Cancers digestifs", children: [{ code: "C03D01", name: "Cancer de la cavité buccale et des lèvres" }, { code: "C03D02", name: "Cancer de l'œsophage" }, { code: "C03D03", name: "Cancer de l'estomac" }, { code: "C03D04", name: "Cancer du foie" }, { code: "C03D05", name: "Cancer de la vésicule biliaire" }, { code: "C03D06", name: "Cancer de l'ampoule de vater" }, { code: "C03D07", name: "Cancer Voies biliaires" }, { code: "C03D08", name: "Cancer du pancréas" }, { code: "C03D09", name: "Cancer de l'intestin grêle" }, { code: "C03D10", name: "Cancer colo-rectal" }, { code: "C03D11", name: "Cancer de l'anus" }, { code: "C03D12", name: "Autres cancers digestifs" }] },
        { code: "C03E", name: "Cancers broncho-pulmonaires", children: [{ code: "C03E01", name: "Cancer de la trachée" }, { code: "C03E02", name: "Cancer du poumon" }, { code: "C03E03", name: "Cancer de la plèvre" }] },
        { code: "C03F", name: "Cancers thoraco-médiastinaux", children: [{ code: "C03F01", name: "Cancer du médiastin" }, { code: "C03F02", name: "Cancer du cœur" }] },
        { code: "C03G", name: "Cancers de l'appareil urinaire", children: [{ code: "C03G01", name: "Cancer du rein" }, { code: "C03G02", name: "Cancer de l'uretère" }, { code: "C03G03", name: "Cancer de la vessie" }] },
        { code: "C03H", name: "Cancer de l'appareil génital féminin", children: [{ code: "C03H01", name: "Cancer de la vulve" }, { code: "C03H02", name: "Cancer du vagin" }, { code: "C03H03", name: "Cancer du col de l'utérus" }, { code: "C03H04", name: "Cancer du corps de l'utérus" }, { code: "C03H05", name: "Cancer de l'ovaire" }, { code: "C03H06", name: "Autres Cancers de l'appareil génital féminin" }] },
        { code: "C03I", name: "Cancer de l'appareil génital masculin", children: [{ code: "C03I01", name: "Cancer de la verge" }, { code: "C03I02", name: "Cancer de la prostate" }, { code: "C03I03", name: "Cancer du testicule" }, { code: "C03I04", name: "Autres Cancers de l'appareil génital masculin" }] },
        { code: "C03J", name: "Cancer du sein", children: [{ code: "C03J01", name: "Carcinome canalaire in situ (CCIS)" }, { code: "C03J02", name: "Adénocarcinome canalaire infiltrant" }, { code: "C03J03", name: "Adénocarcinome lobulaire infiltrant" }, { code: "C03J04", name: "Carcinome médullaire" }, { code: "C03J05", name: "Carcinome mucineux ou colloïde muqueux" }, { code: "C03J06", name: "Adénocarcinome tubuleux" }, { code: "C03J07", name: "Carcinome adénoïde kystique" }, { code: "C03J08", name: "Carcinome apocrine" }, { code: "C03J09", name: "Maladie de Paget du mamelon" }, { code: "C03J10", name: "Cancer du sein chez l'homme" }] },
        { code: "C03K", name: "Cancers du système lymphatique", children: [{ code: "C03K01", name: "Cancer de l'amygdale" }, { code: "C03K02", name: "Cancer de la rate" }, { code: "C03K03", name: "Cancer des ganglions lymphatiques" }, { code: "C03K04", name: "Autres cancers du système lymphatique" }] },
        { code: "C03L", name: "Cancers du sang", children: [{ code: "C03L01", name: "Macroglobulinémie de Waldenström" }, { code: "C03L02", name: "Leucémie lymphoïde aiguë [LLA]" }, { code: "C03L03", name: "Leucémie lymphoïde chronique [LLC]" }, { code: "C03L04", name: "Leucémie myéloblastique aiguë [LMA]" }, { code: "C03L05", name: "Leucémie myéloïde chronique [LMC]" }, { code: "C03L06", name: "Lymphome Hodgkinien" }, { code: "C03L07", name: "Lymphome non Hodgkinien" }, { code: "C03L08", name: "Lymphome de Burkitt" }, { code: "C03L09", name: "Maladie de Vaquez [MV] (= Polyglobulie vraie [PV])" }, { code: "C03L10", name: "Autres cancers du sang" }, { code: "C03L11", name: "Myélome multiple" }] },
        { code: "C03M", name: "Autres cancers de système endocrine", children: [{ code: "C03M01", name: "Cancer de la thyroïde" }, { code: "C03M02", name: "Cancer de la parathyroïde" }, { code: "C03M03", name: "Cancer de la surrénale" }] },
        { code: "C03N", name: "Cancers des os et du cartilage", children: [{ code: "C03N01", name: "Ostéosarcome" }, { code: "C03N02", name: "Chondrosarcome ( tumeur cartilaginea)" }, { code: "C03N03", name: "Sarcome d'Ewing" }, { code: "C03N04", name: "Autres cancers des os et du cartilage" }] },
        { code: "C03O", name: "Cancers des tissus mous et tissus conjonctifs", children: [{ code: "C03O01", name: "Liposarcome" }, { code: "C03O02", name: "Rhabdomyosarcome" }, { code: "C03O03", name: "Leiomyosarcome" }, { code: "C03O04", name: "Angiosarcome" }, { code: "C03O05", name: "Sarcome de Kaposi" }, { code: "C03O06", name: "Fibrosarcome" }, { code: "C03O07", name: "Autres cancers des tissus mous et tissus conjonct" }] },
        { code: "C03P", name: "Cancers de la peau", children: [{ code: "C03P01", name: "Carcinome basocellulaire" }, { code: "C03P02", name: "Carcinome épidélial (spinocellulaire)" }, { code: "C03P03", name: "Mélanome" }, { code: "C03P04", name: "Autres cancers de la peau" }] },
        { code: "C03Q", name: "Autres Cancers", children: [{ code: "C03Q01", name: "Autres cancers" }] }
    ],
  },
  {
    code: "C04",
    name: "Les hémopathies",
    children: [
        { code: "C04A", name: "Anémies hémolytiques chroniques", children: [{ code: "C04A01", name: "Déficit enzymatique en G6-PD et pyruvate kinase" }, { code: "C04A02", name: "Maladie de Minkowski-Chauffard (microsphérocytose)" }, { code: "C04A03", name: "Thalassémies majeures et intermédiaires" }, { code: "C04A04", name: "Drépanocytose (hémoglobinose S)" }, { code: "C04A05", name: "Autre anémies hémolytiques chroniques" }] },
        { code: "C04B", name: "Affections graves de l'hémostase", children: [{ code: "C04B01", name: "Hémophilie A" }, { code: "C04B02", name: "Hémophilie B" }, { code: "C04B03", name: "Maladie de von Willebrand" }, { code: "C04B04", name: "Déficits en facteurs de la coagulation" }, { code: "C04B05", name: "Purpura thrombopénique immunologique chroniqu" }, { code: "C04B06", name: "Autres affections graves de l'hémostase" }] },
        { code: "C04C", name: "Insuffisance médullaire", children: [{ code: "C04C01", name: "Insuffisance médullaire chronique" }, { code: "C04C02", name: "Aplasie médullaire" }] },
        { code: "C04D", name: "Myélodysplasies", children: [{ code: "C04D01", name: "Myélodysplasies" }] },
        { code: "C04E", name: "Déficits immunitaires graves", children: [{ code: "C04E01", name: "Déficits immunitaires primitifs graves" }, { code: "C04E02", name: "Syndrome d'immunodéficience acquise(SIDA maladie" }] },
        { code: "C04F", name: "Autres hémopathies", children: [{ code: "C04F01", name: "Autres hémopathies" }] }
    ],
  },
  {
    code: "C05",
    name: "La Sarcoïdose",
    children: [
      { code: "C05A", name: "Sarcoïdose intra-thoracique", children: [{ code: "C05A01", name: "Sarcoïdose pulmonaire" }, { code: "C05A02", name: "Sarcoïdose médiastino-pulmonaire" }] },
      { code: "C05B", name: "Sarcoïdose extra-thoracique", children: [{ code: "C05B01", name: "Sarcoïdose des ganglions lymphatiques" }, { code: "C05B02", name: "Sarcoïdose de la peau" }, { code: "C05B03", name: "Sarcoïdose oculaire" }, { code: "C05B04", name: "Autre sarcoïdose extra-thoracique" }] },
      { code: "C05C", name: "Sarcoïdose intra- et extra-thoracique", children: [{ code: "C05C01", name: "Autres sarcoïdoses multi-localisations" }] },
    ],
  },
  {
    code: "C06",
    name: "L'hypertension artérielle maligne",
    children: [{ code: "C06A", name: "HTA maligne", children: [{ code: "C06A01", name: "HTA maligne" }] }],
  },
  {
    code: "C07",
    name: "Les maladies cardiaques et vasculaires",
    children: [
        { code: "C07A", name: "Les maladies cardiaques", children: [{ code: "C07A01", name: "Angine de poitrine" }, { code: "C07A02", name: "Infarctus du myocarde" }, { code: "C07A03", name: "Pontage aorto-coronarien" }, { code: "C07A04", name: "Valvulopathie décompensée" }, { code: "C07A05", name: "Remplacement valvulaire prothétique" }, { code: "C07A06", name: "Trouble du rythme avec stimulateur" }] },
        { code: "C07B", name: "Les maladies vasculaires", children: [{ code: "C07B01", name: "Maladies athéromateuses évoluées" }, { code: "C07B02", name: "Artérites des membres inférieurs" }, { code: "C07B03", name: "Accident vasculaire cérébral, méningé et cérébro-méningé" }] }
    ],
  },
  {
    code: "C08",
    name: "Maladies neurologiques",
    children: [
        { code: "C08A", name: "Sclérose en plaques", children: [{ code: "C08A01", name: "Forme rémittente-décurrente" }, { code: "C08A02", name: "Forme secondairement progressive" }, { code: "C08A03", name: "Forme primaire progressive" }] },
        { code: "C08B", name: "Syndromes extra-pyramidaux", children: [{ code: "C08B01", name: "Maladie de Parkinson" }, { code: "C08B02", name: "Syndrome parkinsonien secondaire" }, { code: "C08B03", name: "Autres syndromes extrapyramidaux" }] },
        { code: "C08C", name: "Paralysies, hémiplégies", children: [{ code: "C08C01", name: "Hémiplégies" }, { code: "C08C02", name: "Paraplégies" }, { code: "C08C03", name: "Tétraplégies" }] },
        { code: "C08D", name: "Epilepsies", children: [{ code: "C08D01", name: "Epilepsie du lobe temporal" }, { code: "C08D02", name: "Epilepsie myoclonique progressive" }, { code: "C08D03", name: "Epilepsie post-traumatique" }] }
    ],
  },
  {
    code: "C09",
    name: "Maladies musculaires ou neuromusculaires",
    children: [{ code: "C09A", name: "Polynevrites", children: [{ code: "C09A01", name: "Polynévrite inflammatoires" }, { code: "C09A02", name: "Polynévrite diabétique" }, { code: "C09A03", name: "Autres polynévrites" }] }],
  },
  {
    code: "C10",
    name: "Les encéphalopathies",
    children: [{ code: "C10A", name: "Affections dégénératives", children: [{ code: "C10A01", name: "Maladie d'Alzheimer" }, { code: "C10A02", name: "Démence à corps de Lewy" }, { code: "C10A03", name: "Démence vasculaire" }, { code: "C10A04", name: "Démence de la maladie de Pick" }, { code: "C10A05", name: "Démence de la maladie de Creutzfeldt-Jakob" }, { code: "C10A06", name: "Démence de la maladie de Huntington" }, { code: "C10A07", name: "Autres démences" }] }],
  },
  {
    code: "C11",
    name: "Les néphropathies",
    children: [
        { code: "C11A", name: "Néphropathies glomérulaires", children: [{ code: "C11A04", name: "Glomérulonéphrite membrano-proliférative" }, { code: "C11A05", name: "Néphropathie à IgA (maladie de Berger)" }, { code: "C11A06", name: "Néphropathie diabétique" }, { code: "C11A07", name: "Amylose (AA et AL)" }, { code: "C11A08", name: "Syndrome d'Alport" }] },
        { code: "C11B", name: "Néphropathies tubulo-intersticielles", children: [{ code: "C11B01", name: "Pyélonéphrite chronique" }, { code: "C11B02", name: "Syndrome de Gougerot-Sjögren" }, { code: "C11B03", name: "Autres Néphropathies tubulo-intersticielles chronique" }] },
        { code: "C11D", name: "Néphropathies décompensées", children: [{ code: "C11D01", name: "Insuffisance rénale chronique non dialysée" }, { code: "C11D02", name: "Insuffisance rénale chronique dialysée" }] }
    ],
  },
  {
    code: "C12",
    name: "Les rhumatismes chroniques, inflammatoires",
    children: [
        { code: "C12A", name: "Spondylarthrite ankylosante", children: [{ code: "C12A01", name: "Spondylarthrite ankylosante" }] },
        { code: "C12B", name: "Polyarthrite rhumatoïde", children: [{ code: "C12B01", name: "Polyarthrite rhumatoïde séropositive" }, { code: "C12B02", name: "Polyarthrite rhumatoïde séronégative" }] },
        { code: "C12C", name: "Arthroses graves", children: [{ code: "C12C01", name: "Coxarthrose grave" }, { code: "C12C02", name: "Gonarthrose grave" }, { code: "C12C03", name: "Spondylarthrose grave" }, { code: "C12C04", name: "Omarthrose grave" }, { code: "C12C05", name: "Autres arthroses graves" }] }
    ],
  },
  {
    code: "C13",
    name: "Périartérite noueuse",
    children: [
        { code: "C13A", name: "Périartérite noueuse idiopathique", children: [{ code: "C13A01", name: "Périartérite noueuse idiopathique" }] },
        { code: "C13B", name: "Périartérite noueuse liée au virus de l'Hépatite B", children: [{ code: "C13B01", name: "Périartérite noueuse liée au virus de l'Hépatite B" }] },
        { code: "C13C", name: "Autres formes de périartérite noueuse", children: [{ code: "C13C01", name: "Autres formes de Périartérite noueuse" }] }
    ],
  },
  {
    code: "C14",
    name: "Lupus érythémateux disséminé (LED)",
    children: [
        { code: "C14A", name: "LED spontanés", children: [{ code: "C14A01", name: "LED spontanés" }] },
        { code: "C14B", name: "LED induits", children: [{ code: "C14B01", name: "LED induits" }] }
    ],
  },
  {
    code: "C15",
    name: "Les insuffisances respiratoires chroniques",
    children: [
        { code: "C15A", name: "Les insuffisances respiratoires chroniques par obstruction", children: [{ code: "C15A01", name: "Bronchopneumopathie chronique obstructive (BPCO)" }, { code: "C15A02", name: "DDB (étendue)" }, { code: "C15A03", name: "Emphysème" }, { code: "C15A04", name: "Mucoviscidose" }, { code: "C15A05", name: "Asthme ancien dit \"à dyspnée continue\"" }, { code: "C15A06", name: "Autres insuffisances respiratoires chroniques par" }] },
        { code: "C15B", name: "Les insuffisances respiratoires chroniques par restriction", children: [] }
    ],
  },
  {
    code: "C16",
    name: "Poliomyélite antérieure aiguë",
    children: [
        { code: "C16A", name: "Poliomyélite antérieure aiguë paralytique", children: [{ code: "C16A01", name: "Poliomyélite antérieure aiguë paralytique" }] },
        { code: "C16B", name: "Poliomyélite antérieure aiguë non paralytique", children: [{ code: "C16B01", name: "Poliomyélite antérieure aiguë non paralytique" }] }
    ],
  },
  {
    code: "C17",
    name: "Les maladies métaboliques",
    children: [
        { code: "C17A", name: "Diabètes", children: [{ code: "C17A01", name: "Diabète sucré type 1" }, { code: "C17A02", name: "Diabète sucré type 2 non insulino-traité" }, { code: "C17A03", name: "Diabète sucré type 2 insulino-traité" }, { code: "C17A04", name: "Diabète sucré gestationnel" }, { code: "C17A05", name: "Diabète sucré induit post médicamenteux" }] },
        { code: "C17B", name: "Dysprotéinémies", children: [{ code: "C17B01", name: "Gammapathie monoclonale" }, { code: "C17B02", name: "Autres dysprotéinémies" }] },
        { code: "C17C", name: "Dyslipidoses", children: [{ code: "C17C01", name: "Maladie de Gaucher" }, { code: "C17C02", name: "Maladie de Niemann Pick" }, { code: "C17C03", name: "Autres Dyslipidoses" }] }
    ],
  },
  {
    code: "C18",
    name: "Les cardiopathies congénitales",
    children: [
        { code: "C18A", name: "Cardiopathies congénitales non cyanogènes (CCNC)", children: [{ code: "C18A01", name: "Communication interventriculaire (CIV)" }, { code: "C18A02", name: "Communication interauriculaire (CIA)" }, { code: "C18A03", name: "Persistance du canal artériel" }, { code: "C18A04", name: "Canal atrio-ventriculaire Complet (CAV Complet)" }, { code: "C18A05", name: "Rétrécissement aortique (RAO)" }, { code: "C18A06", name: "Coarctation de l'aorte" }, { code: "C18A07", name: "Anomalies des arcs Aortiques" }, { code: "C18A08", name: "Rétrécissement mitral Congénital (RM)" }, { code: "C18A09", name: "Coeur triatrial" }, { code: "C18A10", name: "Canal Atrio-ventriculaire Partiel (CAV Partiel)" }, { code: "C18A11", name: "Autres cardiopathies congénitales non cyanogènes" }] },
        { code: "C18B", name: "Cardiopathies congénitales cyanogènes (CCC)", children: [{ code: "C18B01", name: "Sténose pulmonaire (AP)" }, { code: "C18B02", name: "Tétralogie de Fallot (T4F)" }, { code: "C18B03", name: "Trilogie de Fallot (T3F)" }, { code: "C18B04", name: "Atrésie de la tricuspide" }, { code: "C18B05", name: "Transposition des gros vaisseaux (TGV)" }, { code: "C18B06", name: "Ventricule droit à double issue (VDDI)" }, { code: "C18B07", name: "Retour veineux pulmonaire anormal (RVPA)" }, { code: "C18B08", name: "Ventricule unique" }, { code: "C18B09", name: "Autres cardiopathies congénitales cyanogènes" }] }
    ],
  },
  {
    code: "C19",
    name: "Les affections endocriniennes...",
    children: [
        { code: "C19A", name: "Syndrome de Cushing", children: [{ code: "C19A01", name: "Adénome corticotrope hypophysaire" }, { code: "C19A02", name: "Syndrome de cushing paranéoplasique" }, { code: "C19A03", name: "Syndrome de cushing secondaire à une tumeur de la" }] },
        { code: "C19B", name: "Adénomes hypophysaires", children: [{ code: "C19B01", name: "Acromégalie et gigantisme (adénome somatotrop" }, { code: "C19B02", name: "Adénome à prolactine" }, { code: "C19B03", name: "Adénome gonadotrope" }, { code: "C19B04", name: "Adénome thyréotrope ou silencieux" }, { code: "C19B05", name: "Craniopharyngiome" }] },
        { code: "C19C", name: "Insuffisance anté-hypophysaire primaire/secondaire", children: [{ code: "C19C01", name: "Hypopituitarisme" }, { code: "C19C02", name: "Syndrome de Sheehan" }] },
        { code: "C19D", name: "Insuffisance surrénalienne primaire/se...", children: [{ code: "C19D01", name: "Maladie d'Addison" }, { code: "C19D02", name: "Syndrome de Nelson" }] },
        { code: "C19E", name: "Déficit en hormone de croissance", children: [{ code: "C19E01", name: "Nanisme" }, { code: "C19E02", name: "Syndrome de Turner" }] },
        { code: "C19F", name: "Syndrome polyuro-polydipsique", children: [{ code: "C19F01", name: "Diabète insipide central" }, { code: "C19F02", name: "Diabète insipide néphrogénique" }] },
        { code: "C19G", name: "L'hirsutisme", children: [{ code: "C19G01", name: "Hirsutisme par hyperplasie congénitale des surrénal" }] },
        { code: "C19H", name: "Puberté précoce centrale/périphérique", children: [{ code: "C19H01", name: "Puberté précoce d'origine centrale" }, { code: "C19H02", name: "Puberté précoce ovarienne ou testiculaire" }] },
        { code: "C19I", name: "Affections thyroïdiennes", children: [{ code: "C19I01", name: "Maladie de Basedow (Hyperthyroïdie)" }, { code: "C19I02", name: "Goitre multinodulaire toxique (Hyperthyroïdie)" }, { code: "C19I03", name: "Nodule toxique (Hyperthyroïdie)" }, { code: "C19I04", name: "Autres Hyperthyroïdies" }, { code: "C19I05", name: "Thyroïdite auto-immune d'Hashimoto" }, { code: "C19I06", name: "Myxœdème idiopathique" }, { code: "C19I07", name: "Hypothiroïdies" }] },
        { code: "C19J", name: "Affections para thyroïdiennes", children: [{ code: "C19J01", name: "Hyperparathyroïdie" }, { code: "C19J02", name: "Hypoparathyroïdie" }] },
        { code: "C19K", name: "Anomalies de la sécrétion pancréatique interne", children: [{ code: "C19K01", name: "Hyperinsulinisme" }, { code: "C19K02", name: "Hyperglycémie" }, { code: "C19K03", name: "Autres anomalies de la sécrétion pancréatique inter" }] }
    ],
  },
  {
    code: "C20",
    name: "Rhumatisme Articulaire Aigu",
    children: [
        { code: "C20A", name: "Rhumatisme articulaire aigu, sans mention d'atteinte cardiaque", children: [{ code: "C20A01", name: "Rhumatisme articulaire aigu, sans mention d'atteinte" }] },
        { code: "C20B", name: "Rhumatisme articulaire aigu, avec atteinte cardiaque", children: [{ code: "C20B01", name: "Rhumatisme articulaire aigu, avec atteinte cardiaque" }] }
    ],
  },
  {
    code: "C21",
    name: "L'ostéomyélite chronique",
    children: [
        { code: "C21A", name: "Ostéomyélite chronique non bactérienne", children: [{ code: "C21A01", name: "Ostéomyélite chronique non bactérienne" }] },
        { code: "C21B", name: "Ostéomyélite chronique bactérienne", children: [{ code: "C21B01", name: "Ostéomyélite chronique bactérienne" }] }
    ],
  },
  {
    code: "C22",
    name: "Les complications graves et durables...",
    children: [
        { code: "C22A", name: "Les complications de gastrectomies", children: [{ code: "C22A01", name: "Les complications de gastrectomies" }] },
        { code: "C22B", name: "Les complications de la maladie ulcéreuse", children: [{ code: "C22B01", name: "Les complications de la maladie ulcéreuse" }] }
    ],
  },
  {
    code: "C23",
    name: "Cirrhoses du foie",
    children: [
        { code: "C23A", name: "Cirrhose post-hépatite virale", children: [{ code: "C23A01", name: "Cirrhose post-hépatite virale" }] },
        { code: "C23B", name: "Cirrhose Médicamenteuse", children: [{ code: "C23B01", name: "Cirrhose Médicamenteuse" }] },
        { code: "C23C", name: "Cirrhose alcoolique du foie" },
        { code: "C23D", name: "Autres cirrhoses" }
    ],
  },
  { code: "C24", name: "Recto-colite hémorragique" },
  { code: "C25", name: "Le pemphigus malin et le psoriasis" },
];
